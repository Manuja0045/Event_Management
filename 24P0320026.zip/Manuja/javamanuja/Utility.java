package com.javamanuja;

/**
 * @author Manuja Nagvekar
 * @Title Event Management System
 */

public class Utility {
    public static String addHours(String time, int hours) {
        String[] parts = time.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);

        hour += hours;
        return String.format("%02d:%02d", hour % 24, minute);
    }
}

