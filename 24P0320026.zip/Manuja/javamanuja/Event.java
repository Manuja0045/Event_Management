/**
 * @author Manuja Nagvekar
 * @Title Event Management System
 */

package com.javamanuja;

public class Event {
    private String type;
    private int count;
    private String startTime;
    private String endTime;

    public Event(String type, int count, String startTime, String endTime) {
        this.type = type;
        this.count = count;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return type + " (" + count + " items): " + startTime + " - " + endTime;
    }
}