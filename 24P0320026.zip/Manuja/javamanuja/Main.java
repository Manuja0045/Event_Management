/**
 * @author Manuja Nagvekar
 * @Title Event Management System
 */

package com.javamanuja;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EventScheduler scheduler = new EventScheduler();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Conference Scheduler ---");
            System.out.println("1. View ICON Schedule");
            System.out.println("2. View FIRE Schedule");
            System.out.println("3. Generate Schedule");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        scheduler.displaySchedule("ICON");
                        break;
                    case 2:
                        scheduler.displaySchedule("FIRE");
                        break;
                    case 3:
                        scheduler.generateSchedules();
                        System.out.println("Schedules generated successfully!");
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                scanner.next();
            }
        }
    }
}
