/**
 * @author Manuja Nagvekar
 * @Title Event Management System
 */

package com.javamanuja;


import java.util.ArrayList;
import java.util.List;
/**
 * 
 */
public class EventScheduler {
    private List<Conference> conferences;

    public EventScheduler() {
        conferences = new ArrayList<>();
        conferences.add(new Conference("ICON", 14, 17));
        conferences.add(new Conference("FIRE", 15, 18));
    }

    public void generateSchedules() {
        for (Conference conference : conferences) {
            if (conference.getName().equals("ICON")) {
                conference.addEvent(new Event("Tutorial", 8, "09:00", "12:00"));
                conference.addEvent(new Event("Workshop", 1, "13:00", "16:00"));
                conference.schedulePaperPresentations(24, 6, 3);
                conference.schedulePosterPresentations(40, 10);
            } else if (conference.getName().equals("FIRE")) {
                conference.addEvent(new Event("Workshop", 2, "09:00", "12:00"));
                conference.schedulePaperPresentations(18, 6, 3);
                conference.schedulePosterPresentations(20, 5);
            }
        }
    }

    public void displaySchedule(String conferenceName) {
        for (Conference conference : conferences) {
            if (conference.getName().equals(conferenceName)) {
                conference.displaySchedule();
                return;
            }
        }
        System.out.println("Conference not found!");
    }
}

