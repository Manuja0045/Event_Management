/**
 * Represents a conference event, including its schedule and events.
 * This class allows the scheduling of paper and poster presentations.
 * The conference runs from a start date to an end date, and can have multiple events scheduled.
 * 
 * @author Manuja Nagvekar
 * @Title Event Management System
 */
package com.javamanuja;

import java.util.ArrayList;
import java.util.List;

public class Conference {
    private String name;
    private int startDate;
    private int endDate;
    private List<Event> events;

    /**
     * Constructs a new Conference object with a specified name, start date, and end date.
     * Initializes an empty list of events.
     * 
     * @param name The name of the conference.
     * @param startDate The start date of the conference (in format YYYYMMDD).
     * @param endDate The end date of the conference (in format YYYYMMDD).
     */
    public Conference(String name, int startDate, int endDate) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.events = new ArrayList<>();
    }

    /**
     * Gets the name of the conference.
     * 
     * @return The name of the conference.
     */
    public String getName() {
        return name;
    }

    /**
     * Adds an event to the conference's schedule.
     * 
     * @param event The event to be added to the schedule.
     */
    public void addEvent(Event event) {
        events.add(event);
    }

    /**
     * Schedules paper presentation sessions for the conference.
     * This method calculates the number of slots required and schedules paper presentations
     * with breaks in between. Each slot has a specified number of papers to present.
     * 
     * @param totalPapers The total number of papers to be presented.
     * @param papersPerSlot The number of papers to be presented per session/slot.
     * @param hoursPerSlot The duration (in hours) of each paper presentation session.
     */
    public void schedulePaperPresentations(int totalPapers, int papersPerSlot, int hoursPerSlot) {
        int slots = totalPapers / papersPerSlot;
        String time = "09:00";
        for (int i = 1; i <= slots; i++) {
            events.add(new Event("Paper Presentation", papersPerSlot, time, Utility.addHours(time, hoursPerSlot)));
            time = Utility.addHours(time, hoursPerSlot + 1); // 1-hour break
        }
    }

    /**
     * Schedules poster presentation sessions for the conference.
     * This method calculates the number of days required for poster presentations,
     * and schedules a poster presentation session each day at a fixed time.
     * 
     * @param totalPosters The total number of posters to be presented.
     * @param postersPerDay The number of posters to be presented each day.
     */
    public void schedulePosterPresentations(int totalPosters, int postersPerDay) {
        int days = totalPosters / postersPerDay;
        for (int i = 0; i < days; i++) {
            events.add(new Event("Poster Presentation", postersPerDay, "12:30", "13:30"));
        }
    }

    /**
     * Displays the full schedule of events for the conference, including each event's
     * name, number of participants, and time slot.
     */
    public void displaySchedule() {
        System.out.println("\nSchedule for " + name + " (" + startDate + " to " + endDate + " December 2024):");
        for (Event event : events) {
            System.out.println(event);
        }
    }
}
